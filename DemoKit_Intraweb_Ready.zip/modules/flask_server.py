from flask import Flask, render_template_string, abort
import os
import json
import re

app = Flask(__name__)
DATA_DIR = "./exported_docs"

@app.route("/")
def index():
    files = [f for f in os.listdir(DATA_DIR) if f.endswith(".json")]
    links = [f'<li><a href="/doc/{f[:-5]}">{f}</a></li>' for f in files]
    return f"<h1>DemoKit Documents</h1><ul>{''.join(links)}</ul>"

@app.route("/doc/<doc_id>")
def show_doc(doc_id):
    path = os.path.join(DATA_DIR, f"{doc_id}.json")
    if not os.path.exists(path):
        abort(404)
    with open(path, "r", encoding="utf-8") as f:
        doc = json.load(f)
    title = doc.get("title", f"Document {doc_id}")
    body = doc.get("body", "")
    # Convert internal links
    body = re.sub(r'\[(.+?)\]\(doc:(\d+)\)', r'<a href="/doc/\2">\1</a>', body)
    return render_template_string(f"""
    <h2>{title}</h2>
    <div>{body}</div>
    <p><a href="/">← Back to index</a></p>
    """)

if __name__ == "__main__":
    app.run(debug=True)

